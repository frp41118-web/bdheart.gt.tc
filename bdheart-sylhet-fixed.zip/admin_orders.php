<?php
// BD HEART – admin sync: list orders from database, update status, delete, set Bangla QR image
header('Content-Type: application/json; charset=utf-8');
session_set_cookie_params(['lifetime' => 30 * 86400, 'path' => '/', 'httponly' => true, 'samesite' => 'Lax']);
session_start();
$C = require __DIR__ . '/config.php';
$in = json_decode(file_get_contents('php://input'), true) ?: [];
function out($d) { echo json_encode($d, JSON_UNESCAPED_UNICODE); exit; }
$keyOk = strlen($C['admin_key']) >= 10 && $C['admin_key'] !== 'CHANGE_ME' && hash_equals($C['admin_key'], (string)($in['key'] ?? ''));
$a = $_GET['a'] ?? '';
if ($a === 'logout') { unset($_SESSION['adm']); out(['ok' => true]); }
if ($a === 'login') {
  if (!$keyOk) { sleep(1); http_response_code(403); out(['ok' => false, 'denied' => true]); }
  session_regenerate_id(true); $_SESSION['adm'] = 1; out(['ok' => true]);
}
if (!$keyOk && empty($_SESSION['adm'])) { sleep(1); http_response_code(403); out(['ok' => false, 'denied' => true]); }
try { $db = new PDO("mysql:host={$C['db_host']};dbname={$C['db_name']};charset=utf8mb4", $C['db_user'], $C['db_pass'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]); }
catch (Exception $e) { out(['ok' => false]); }
try { $db->exec("ALTER TABLE orders ADD status VARCHAR(20) DEFAULT 'PENDING'"); } catch (Exception $e) {}
if ($a === 'list') {
  $r = [];
  try { $rows = $db->query('SELECT o.id,o.status,o.data,u.photo FROM orders o LEFT JOIN users u ON u.id=o.uid ORDER BY o.created DESC LIMIT 500')->fetchAll(PDO::FETCH_ASSOC); }
  catch (Exception $e) { $rows = $db->query('SELECT id,status,data FROM orders ORDER BY created DESC LIMIT 500')->fetchAll(PDO::FETCH_ASSOC); }
  foreach ($rows as $x) {
    $o = json_decode($x['data'], true); if (!$o) continue; $o['status'] = $x['status'] ?: 'PENDING';
    $o['photo'] = (!empty($x['photo']) && preg_match('/^u\d+_[a-f0-9]+\.jpg$/', $x['photo'])) ? 'avatars/' . $x['photo'] : '';
    $r[] = $o;
  }
  out(['ok' => true, 'orders' => $r]);
}
if ($a === 'status') { $db->prepare('UPDATE orders SET status=? WHERE id=?')->execute([substr($in['status'] ?? '', 0, 20), $in['id'] ?? '']); out(['ok' => true]); }
if ($a === 'delete') { $q = $db->prepare('DELETE FROM orders WHERE id=?'); foreach (($in['ids'] ?? []) as $id) $q->execute([$id]); out(['ok' => true]); }
if ($a === 'qr') {
  $b = base64_decode(preg_replace('#^data:image/\w+;base64,#', '', $in['img'] ?? ''), true);
  if (!$b || strlen($b) > 2000000 || !@getimagesizefromstring($b)) out(['ok' => false, 'err' => 'ছবি ঠিক নেই']);
  out(['ok' => file_put_contents(__DIR__ . '/bangla-qr.jpg', $b) !== false, 'err' => 'ফাইল সেভ হয়নি']);
}
out(['ok' => false]);
