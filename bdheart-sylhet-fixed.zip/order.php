<?php
// BD HEART – order receiver: saves order to MySQL + sends SMS to customer & admin
session_start();
header('Content-Type: application/json; charset=utf-8');
$C = require __DIR__ . '/config.php';
function sms($C, $to, $msg) {
  if (strpos($C['sms_url'], 'YOUR-') !== false) return false;
  $u = str_replace(['{to}', '{msg}'], ['88' . ltrim($to, '+88'), rawurlencode($msg)], $C['sms_url']);
  $ch = curl_init($u); curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => 1, CURLOPT_TIMEOUT => 10]);
  $r = curl_exec($ch); curl_close($ch); return $r !== false;
}
$o = json_decode(file_get_contents('php://input'), true);
if (!$o || !preg_match('/^01[3-9]\d{8}$/', $o['phone'] ?? '')) { http_response_code(400); echo '{"ok":false}'; exit; }
$saved = false;
try {
  $db = new PDO("mysql:host={$C['db_host']};dbname={$C['db_name']};charset=utf8mb4", $C['db_user'], $C['db_pass'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
  $db->exec("CREATE TABLE IF NOT EXISTS orders (id VARCHAR(20) PRIMARY KEY, name VARCHAR(120), phone VARCHAR(15), zone VARCHAR(40), address TEXT, payment VARCHAR(20), total INT, data MEDIUMTEXT, uid INT NULL, created TIMESTAMP DEFAULT CURRENT_TIMESTAMP) CHARACTER SET utf8mb4");
  try { $db->exec('ALTER TABLE orders ADD uid INT NULL'); } catch (Exception $e) {}
  try { $db->exec("ALTER TABLE orders ADD status VARCHAR(20) DEFAULT 'PENDING'"); } catch (Exception $e) {}
  $db->prepare("REPLACE INTO orders (id,name,phone,zone,address,payment,total,data,uid) VALUES (?,?,?,?,?,?,?,?,?)")
     ->execute([$o['id'], $o['name'], $o['phone'], $o['zone'], $o['address'], $o['payment'], (int)$o['total'], json_encode($o, JSON_UNESCAPED_UNICODE), $_SESSION['uid'] ?? null]);
  $saved = true;
} catch (Exception $e) {}
$cust = "BD HEART: আপনার অর্ডার {$o['id']} গ্রহণ করা হয়েছে। মোট {$o['total']} টাকা। ধন্যবাদ।";
$adm  = "New order {$o['id']}: {$o['name']}, {$o['phone']}, {$o['zone']}, Total {$o['total']} Tk, {$o['payment']}";
$s1 = sms($C, $o['phone'], $cust);
$s2 = sms($C, $C['admin_phone'], $adm);
echo json_encode(['ok' => $saved || $s2, 'saved' => $saved, 'sms' => $s1 && $s2]);
