<?php
return [
  'db_host' => 'sql106.infinityfree.com',
  'db_name' => 'if0_43471074_bdheart',
  'db_user' => 'if0_43471074',
  'db_pass' => 'Jayed4118bd',          // <-- এখানে নতুন পাসওয়ার্ড বসান
  'admin_key' => 'Jayed4118bd',               // <-- অ্যাডমিন প্যানেল সিঙ্কের গোপন পাসওয়ার্ড (কমপক্ষে ১০ অক্ষর)
  'admin_phone' => '01727084118',            // অ্যাডমিনের নম্বর
  // SMS gateway URL (আপনার SMS কোম্পানির API লিংক). {to} ও {msg} অটো বসবে
  'sms_url' => 'https://YOUR-SMS-PROVIDER/api?api_key=YOUR_KEY&senderid=YOUR_ID&number={to}&message={msg}',
];
