<?php
// BD HEART – customer accounts (email or mobile + password), my orders
session_start();
header('Content-Type: application/json; charset=utf-8');
$C = require __DIR__ . '/config.php';
$in = json_decode(file_get_contents('php://input'), true) ?: [];
$a = $_GET['a'] ?? '';
function out($d) { echo json_encode($d, JSON_UNESCAPED_UNICODE); exit; }
try { $db = new PDO("mysql:host={$C['db_host']};dbname={$C['db_name']};charset=utf8mb4", $C['db_user'], $C['db_pass'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]); }
catch (Exception $e) { out(['ok' => false, 'err' => 'সার্ভার সংযোগ হয়নি']); }
$db->exec("CREATE TABLE IF NOT EXISTS users (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(120), email VARCHAR(160) UNIQUE NULL, phone VARCHAR(15) UNIQUE NULL, pass VARCHAR(255), address TEXT, created TIMESTAMP DEFAULT CURRENT_TIMESTAMP) CHARACTER SET utf8mb4");
$db->exec("CREATE TABLE IF NOT EXISTS orders (id VARCHAR(20) PRIMARY KEY, name VARCHAR(120), phone VARCHAR(15), zone VARCHAR(40), address TEXT, payment VARCHAR(20), total INT, data MEDIUMTEXT, uid INT NULL, created TIMESTAMP DEFAULT CURRENT_TIMESTAMP) CHARACTER SET utf8mb4");
try { $db->exec("ALTER TABLE orders ADD uid INT NULL"); } catch (Exception $e) {}
try { $db->exec("ALTER TABLE users ADD photo VARCHAR(80) NULL"); } catch (Exception $e) {}
try { $db->exec("ALTER TABLE users ADD addr_json TEXT NULL"); } catch (Exception $e) {}
$uid = $_SESSION['uid'] ?? null;
$ph = trim($in['phone'] ?? ''); $em = strtolower(trim($in['email'] ?? ''));
if ($a === 'register' || $a === 'login') {
  $pw = (string)($in['pass'] ?? '');
  if (strlen($pw) < 6) out(['ok' => false, 'err' => 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষর']);
  if ($a === 'register') {
    $name = mb_substr(trim($in['name'] ?? ''), 0, 100);
    if ($name === '') out(['ok' => false, 'err' => 'নাম দিন']);
    if ($em === '' && $ph === '') out(['ok' => false, 'err' => 'ইমেইল অথবা মোবাইল নম্বর দিন']);
    if ($em !== '' && !filter_var($em, FILTER_VALIDATE_EMAIL)) out(['ok' => false, 'err' => 'সঠিক ইমেইল দিন']);
    if ($ph !== '' && !preg_match('/^01[3-9]\d{8}$/', $ph)) out(['ok' => false, 'err' => 'সঠিক মোবাইল নম্বর দিন']);
    $q = $db->prepare('SELECT id FROM users WHERE (email=? AND ?<>"") OR (phone=? AND ?<>"")'); $q->execute([$em, $em, $ph, $ph]);
    if ($q->fetch()) out(['ok' => false, 'err' => 'এই ইমেইল/নম্বরে আগেই অ্যাকাউন্ট আছে, লগইন করুন']);
    $db->prepare('INSERT INTO users (name,email,phone,pass,address) VALUES (?,?,?,?,"")')->execute([$name, $em ?: null, $ph ?: null, password_hash($pw, PASSWORD_DEFAULT)]);
    $uid = (int)$db->lastInsertId();
  } else {
    $id = strtolower(trim($in['id'] ?? ''));
    $q = $db->prepare('SELECT * FROM users WHERE email=? OR phone=?'); $q->execute([$id, $id]); $u = $q->fetch(PDO::FETCH_ASSOC);
    if (!$u || !password_verify($pw, $u['pass'])) out(['ok' => false, 'err' => 'ইমেইল/নম্বর বা পাসওয়ার্ড ভুল']);
    $uid = (int)$u['id'];
  }
  session_regenerate_id(true); $_SESSION['uid'] = $uid;
}
if ($a === 'logout') { session_destroy(); out(['ok' => true]); }
if (!$uid) out(['ok' => false, 'guest' => true]);
if ($a === 'addr') {
  $ad = is_array($in['addr'] ?? null) ? $in['addr'] : [];
  $cl = []; foreach (['name', 'phone', 'div', 'dis', 'area', 'det', 'type'] as $k) $cl[$k] = mb_substr(trim((string)($ad[$k] ?? '')), 0, 300);
  $txt = trim($cl['det'] . ', ' . $cl['area'] . ', ' . $cl['dis'] . ', ' . $cl['div'], ', ');
  $db->prepare('UPDATE users SET addr_json=?, address=? WHERE id=?')->execute([json_encode($cl, JSON_UNESCAPED_UNICODE), mb_substr($txt, 0, 500), $uid]);
}
if ($a === 'photo') {
  $raw = (string)($in['img'] ?? '');
  $b = base64_decode(preg_replace('#^data:image/\w+;base64,#', '', $raw), true);
  $info = $b ? @getimagesizefromstring($b) : false;
  if (!$b || strlen($b) > 600000 || !$info || $info['mime'] !== 'image/jpeg') out(['ok' => false, 'err' => 'ছবি ঠিক নেই (JPEG, ছোট সাইজ)']);
  $dir = __DIR__ . '/avatars'; if (!is_dir($dir)) { @mkdir($dir, 0755, true); @file_put_contents($dir . '/index.html', ''); @file_put_contents($dir . '/.htaccess', "Options -Indexes\n"); }
  $old = $db->prepare('SELECT photo FROM users WHERE id=?'); $old->execute([$uid]); $op = $old->fetchColumn();
  $fn = 'u' . $uid . '_' . bin2hex(random_bytes(5)) . '.jpg';
  if (file_put_contents($dir . '/' . $fn, $b) === false) out(['ok' => false, 'err' => 'ছবি সেভ হয়নি']);
  if ($op && preg_match('/^u\d+_[a-f0-9]+\.jpg$/', $op)) @unlink($dir . '/' . $op);
  $db->prepare('UPDATE users SET photo=? WHERE id=?')->execute([$fn, $uid]);
}
if ($a === 'photo_del') {
  $old = $db->prepare('SELECT photo FROM users WHERE id=?'); $old->execute([$uid]); $op = $old->fetchColumn();
  if ($op && preg_match('/^u\d+_[a-f0-9]+\.jpg$/', $op)) @unlink(__DIR__ . '/avatars/' . $op);
  $db->prepare('UPDATE users SET photo=NULL WHERE id=?')->execute([$uid]);
}
if ($a === 'save') {
  $db->prepare('UPDATE users SET name=?, address=? WHERE id=?')->execute([mb_substr(trim($in['name'] ?? ''), 0, 100), mb_substr(trim($in['address'] ?? ''), 0, 500), $uid]);
  if (preg_match('/^01[3-9]\d{8}$/', $ph)) { try { $db->prepare('UPDATE users SET phone=? WHERE id=? AND phone IS NULL')->execute([$ph, $uid]); } catch (Exception $e) {} }
}
$q = $db->prepare('SELECT name,email,phone,address,photo,addr_json FROM users WHERE id=?'); $q->execute([$uid]); $user = $q->fetch(PDO::FETCH_ASSOC);
try { $db->exec("ALTER TABLE orders ADD status VARCHAR(20) DEFAULT 'PENDING'"); } catch (Exception $e) {}
$q = $db->prepare('SELECT id,total,payment,zone,address,status,data,created FROM orders WHERE uid=? OR (phone IS NOT NULL AND phone=?) ORDER BY created DESC LIMIT 30'); $q->execute([$uid, (string)$user['phone']]);
$orders = [];
foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $r) {
  $d = json_decode($r['data'] ?? '', true) ?: [];
  $r['items'] = $d['items'] ?? [];
  $r['deliveryFee'] = $d['deliveryFee'] ?? 0;
  $r['status'] = $r['status'] ?: 'PENDING';
  unset($r['data']);
  $orders[] = $r;
}
out(['ok' => true, 'user' => $user, 'orders' => $orders]);
